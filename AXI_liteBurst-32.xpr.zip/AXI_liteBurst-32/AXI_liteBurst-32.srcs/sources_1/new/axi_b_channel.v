`timescale 1ns/1ps

module axi_b_channel (
    input  wire       clk,
    input  wire       aresetn,
    
    // Internal trigger and status inputs
    input  wire       wr_complete_pulse, // Pulsed when final write beat is committed
    input  wire [1:0] gen_bresp,         // Calculated response code from response_generator
    
    // AXI4 Write Response Channel Interface
    output wire [1:0] s_axi_bresp,
    output wire       s_axi_bvalid,
    input  wire       s_axi_bready,
    
    // Status back to control engine
    output wire       b_handshake_done
);

    reg [1:0] bresp_r;
    reg       bvalid_r;

    // Successful handshake completion
    assign b_handshake_done = bvalid_r && s_axi_bready;

    // Response register and handshake state tracking
    always @(posedge clk) begin
        if (!aresetn) begin
            bvalid_r <= 1'b0;
            bresp_r  <= 2'b00;
        end else begin
            if (wr_complete_pulse && !bvalid_r) begin
                // Latch response code and assert BVALID
                bvalid_r <= 1'b1;
                bresp_r  <= gen_bresp;
            end else if (b_handshake_done) begin
                // Deassert BVALID once master acknowledges
                bvalid_r <= 1'b0;
            end
        end
    end

    assign s_axi_bvalid = bvalid_r;
    assign s_axi_bresp  = bresp_r;

endmodule
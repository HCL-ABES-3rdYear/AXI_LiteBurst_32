`timescale 1ns/1ps

module axi_ar_channel #(
    parameter ADDR_WIDTH     = 32,
    parameter BURST_LEN_BITS = 4
)(
    input  wire                       clk,
    input  wire                       aresetn,
    
    // AXI4 Read Address Channel Interface
    input  wire [ADDR_WIDTH-1:0]      s_axi_araddr,
    input  wire [BURST_LEN_BITS-1:0]  s_axi_arlen,
    input  wire [1:0]                 s_axi_arburst,
    input  wire                       s_axi_arvalid,
    output wire                       s_axi_arready,
    
    // Internal Control & Handshake Status
    input  wire                       ar_pipe_busy,
    output reg  [ADDR_WIDTH-1:0]      ar_captured_addr,
    output reg  [BURST_LEN_BITS-1:0]  ar_captured_len,
    output reg  [1:0]                 ar_captured_burst,
    output wire                       ar_handshake_done
);

    reg arready_r;

    // Speculatively assert ARREADY when the read datapath is idle/ready
    always @(posedge clk) begin
        if (!aresetn) begin
            arready_r <= 1'b0;
        end else begin
            arready_r <= !ar_pipe_busy;
        end
    end

    assign s_axi_arready     = arready_r;
    assign ar_handshake_done = s_axi_arvalid && s_axi_arready;

    // Capture transfer attributes on successful handshake
    always @(posedge clk) begin
        if (!aresetn) begin
            ar_captured_addr  <= {ADDR_WIDTH{1'b0}};
            ar_captured_len   <= {BURST_LEN_BITS{1'b0}};
            ar_captured_burst <= 2'b00;
        end else if (ar_handshake_done) begin
            ar_captured_addr  <= s_axi_araddr;
            ar_captured_len   <= s_axi_arlen;
            ar_captured_burst <= s_axi_arburst;
        end
    end

endmodule
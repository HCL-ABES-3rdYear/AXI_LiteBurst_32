`timescale 1ns/1ps

module write_data_path #(
    parameter DATA_WIDTH = 32,
    parameter STRB_WIDTH = DATA_WIDTH / 8
)(
    input  wire                  clk,
    input  wire                  aresetn,
    
    // Control and target selects
    input  wire                  wr_en,
    input  wire                  sel_ctrl,
    input  wire                  sel_status,
    input  wire                  sel_config,
    input  wire                  sel_mem,
    
    // Ingress write data and byte strobes
    input  wire [DATA_WIDTH-1:0] wdata,
    input  wire [STRB_WIDTH-1:0] wstrb,
    input  wire [DATA_WIDTH-1:0] orig_data,
    
    // Processed data & enables
    output reg  [DATA_WIDTH-1:0] masked_wdata,
    output wire                  ctrl_we,
    output wire                  config_we,
    output wire [STRB_WIDTH-1:0] mem_we,
    output reg                   wr_prot_err
);

    integer i;

    // Strobe masking logic: merge wdata and orig_data on a byte-by-byte basis
    always @(*) begin
        for (i = 0; i < STRB_WIDTH; i = i + 1) begin
            if (wstrb[i]) begin
                masked_wdata[(i*8) +: 8] = wdata[(i*8) +: 8];
            end else begin
                masked_wdata[(i*8) +: 8] = orig_data[(i*8) +: 8];
            end
        end
    end

    // STATUS register at 0x04 is Read-Only; writing to it triggers a slave error (SLVERR)
    always @(*) begin
        if (wr_en && sel_status) begin
            wr_prot_err = 1'b1;
        end else begin
            wr_prot_err = 1'b0;
        end
    end

    // Qualified write enables
    assign ctrl_we   = wr_en && sel_ctrl;
    assign config_we = wr_en && sel_config;
    assign mem_we    = (wr_en && sel_mem) ? wstrb : {STRB_WIDTH{1'b0}};

endmodule
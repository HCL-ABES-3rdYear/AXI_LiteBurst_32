`timescale 1ns/1ps

module axi_aw_channel #(
    parameter ADDR_WIDTH      = 32,
    parameter BURST_LEN_BITS  = 4
)(
    input  wire                       clk,
    input  wire                       aresetn,
    
    // AXI4 Write Address Channel Interface
    input  wire [ADDR_WIDTH-1:0]      s_axi_awaddr,
    input  wire [BURST_LEN_BITS-1:0]  s_axi_awlen,
    input  wire [1:0]                 s_axi_awburst,
    input  wire                       s_axi_awvalid,
    output wire                       s_axi_awready,
    
    // Internal Control & Handshake Status
    input  wire                       aw_fifo_full,
    output reg  [ADDR_WIDTH-1:0]      aw_captured_addr,
    output reg  [BURST_LEN_BITS-1:0]  aw_captured_len,
    output reg  [1:0]                 aw_captured_burst,
    output wire                       aw_handshake_done
);

    // Internal ready register
    reg awready_r;

    // Ready generation: assert when not reset and downstream pipeline is not busy/full
    always @(posedge clk) begin
        if (!aresetn) begin
            awready_r <= 1'b0;
        end else begin
            // Ready can be asserted speculatively if we have room
            awready_r <= !aw_fifo_full;
        end
    end

    // Handshake occurs when VALID and READY are simultaneously high
    assign s_axi_awready     = awready_r;
    assign aw_handshake_done = s_axi_awvalid && s_axi_awready;

    // Address & metadata capture register
    always @(posedge clk) begin
        if (!aresetn) begin
            aw_captured_addr  <= {ADDR_WIDTH{1'b0}};
            aw_captured_len   <= {BURST_LEN_BITS{1'b0}};
            aw_captured_burst <= 2'b00;
        end else if (aw_handshake_done) begin
            aw_captured_addr  <= s_axi_awaddr;
            aw_captured_len   <= s_axi_awlen;
            aw_captured_burst <= s_axi_awburst;
        end
    end

endmodule
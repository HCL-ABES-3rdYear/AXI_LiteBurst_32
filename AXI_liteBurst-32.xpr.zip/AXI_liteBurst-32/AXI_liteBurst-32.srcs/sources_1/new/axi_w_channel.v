`timescale 1ns/1ps

module axi_w_channel #(
    parameter DATA_WIDTH = 32,
    parameter STRB_WIDTH = DATA_WIDTH / 8
)(
    input  wire                   clk,
    input  wire                   aresetn,
    
    // AXI4 Write Data Channel Interface
    input  wire [DATA_WIDTH-1:0]  s_axi_wdata,
    input  wire [STRB_WIDTH-1:0]  s_axi_wstrb,
    input  wire                   s_axi_wlast,
    input  wire                   s_axi_wvalid,
    output wire                   s_axi_wready,
    
    // Internal Control & Handshake Status
    input  wire                   w_fifo_full,
    input  wire                   expected_last_beat,
    output reg  [DATA_WIDTH-1:0]  w_captured_data,
    output reg  [STRB_WIDTH-1:0]  w_captured_strb,
    output reg                    w_captured_last,
    output wire                   w_beat_ack,
    output reg                    wlast_error
);

    reg wready_r;

    // Speculatively assert READY whenever downstream write datapath has capacity
    always @(posedge clk) begin
        if (!aresetn) begin
            wready_r <= 1'b0;
        end else begin
            wready_r <= !w_fifo_full;
        end
    end

    assign s_axi_wready = wready_r;
    assign w_beat_ack   = s_axi_wvalid && s_axi_wready;

    // Latch payload on successful beat handshake
    always @(posedge clk) begin
        if (!aresetn) begin
            w_captured_data <= {DATA_WIDTH{1'b0}};
            w_captured_strb <= {STRB_WIDTH{1'b0}};
            w_captured_last <= 1'b0;
            wlast_error     <= 1'b0;
        end else begin
            wlast_error <= 1'b0; // Default clear
            if (w_beat_ack) begin
                w_captured_data <= s_axi_wdata;
                w_captured_strb <= s_axi_wstrb;
                w_captured_last <= s_axi_wlast;
                
                // Mismatch detection: master flagged last but counter disagrees, or vice versa
                if (s_axi_wlast != expected_last_beat) begin
                    wlast_error <= 1'b1;
                end
            end
        end
    end

endmodule
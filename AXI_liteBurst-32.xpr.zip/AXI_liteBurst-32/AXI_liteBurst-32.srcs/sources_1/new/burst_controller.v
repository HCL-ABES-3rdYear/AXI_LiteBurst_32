`timescale 1ns/1ps

module burst_controller #(
    parameter ADDR_WIDTH     = 32,
    parameter DATA_WIDTH     = 32,
    parameter BURST_LEN_BITS = 4
)(
    input  wire                       clk,
    input  wire                       aresetn,
    
    // Handshake control strobes
    input  wire                       burst_start, // Pulse on AW/AR address handshake
    input  wire                       beat_ack,    // Pulse on W/R data handshake beat
    
    // Burst parameters captured from channel
    input  wire [ADDR_WIDTH-1:0]      init_addr,
    input  wire [BURST_LEN_BITS-1:0]  burst_len,   // 0 = 1 beat, 15 = 16 beats
    input  wire [1:0]                 burst_type,  // 00: FIXED, 01: INCR, 10: WRAP
    
    // Dynamic address & status tracking
    output wire [ADDR_WIDTH-1:0]      current_addr,
    output wire [BURST_LEN_BITS-1:0]  current_beat,
    output wire                       is_last_beat,
    output wire                       burst_busy
);

    // Burst Type encodings as per AMBA AXI spec
    localparam [1:0] BURST_FIXED = 2'b00;
    localparam [1:0] BURST_INCR  = 2'b01;
    localparam [1:0] BURST_WRAP  = 2'b10;

    // Address increment step (4 bytes per beat for 32-bit data)
    localparam [ADDR_WIDTH-1:0] ADDR_STEP = DATA_WIDTH / 8;

    reg [ADDR_WIDTH-1:0]     addr_r;
    reg [BURST_LEN_BITS-1:0] beat_cnt_r;
    reg [BURST_LEN_BITS-1:0] len_r;
    reg [1:0]                type_r;
    reg                      busy_r;

    // Combinational wrap boundary mask calculation
    reg [ADDR_WIDTH-1:0] wrap_mask;
    always @(*) begin
        case (len_r)
            4'd1:    wrap_mask = (ADDR_STEP * 2)  - 1; // 2 beats:  8 bytes (mask 0x07)
            4'd3:    wrap_mask = (ADDR_STEP * 4)  - 1; // 4 beats: 16 bytes (mask 0x0F)
            4'd7:    wrap_mask = (ADDR_STEP * 8)  - 1; // 8 beats: 32 bytes (mask 0x1F)
            4'd15:   wrap_mask = (ADDR_STEP * 16) - 1; // 16 beats: 64 bytes (mask 0x3F)
            default: wrap_mask = (ADDR_STEP * 16) - 1;
        endcase
    end

    // Next address combinational logic
    reg [ADDR_WIDTH-1:0] next_addr;
    always @(*) begin
        case (type_r)
            BURST_FIXED: begin
                next_addr = addr_r;
            end
            BURST_INCR: begin
                next_addr = addr_r + ADDR_STEP;
            end
            BURST_WRAP: begin
                next_addr = (addr_r & ~wrap_mask) | ((addr_r + ADDR_STEP) & wrap_mask);
            end
            default: begin
                next_addr = addr_r + ADDR_STEP;
            end
        endcase
    end

    // Sequential tracking
    always @(posedge clk) begin
        if (!aresetn) begin
            addr_r     <= {ADDR_WIDTH{1'b0}};
            beat_cnt_r <= {BURST_LEN_BITS{1'b0}};
            len_r      <= {BURST_LEN_BITS{1'b0}};
            type_r     <= 2'b00;
            busy_r     <= 1'b0;
        end else begin
            if (burst_start) begin
                addr_r     <= init_addr;
                beat_cnt_r <= {BURST_LEN_BITS{1'b0}};
                len_r      <= burst_len;
                type_r     <= burst_type;
                // If single transfer (burst_len == 0), no multi-beat busy phase
                busy_r     <= (burst_len != {BURST_LEN_BITS{1'b0}});
            end else if (beat_ack && busy_r) begin
                addr_r     <= next_addr;
                beat_cnt_r <= beat_cnt_r + 1'b1;

                if (beat_cnt_r + 1'b1 == len_r) begin
                    busy_r <= 1'b0; // Final beat has completed
                end
            end
        end
    end

    // Output assignments
    assign current_addr = addr_r;
    assign current_beat = beat_cnt_r;
    assign is_last_beat = (burst_start) ? (burst_len == {BURST_LEN_BITS{1'b0}}) :
                                          (beat_cnt_r == len_r);
    assign burst_busy   = busy_r;

endmodule

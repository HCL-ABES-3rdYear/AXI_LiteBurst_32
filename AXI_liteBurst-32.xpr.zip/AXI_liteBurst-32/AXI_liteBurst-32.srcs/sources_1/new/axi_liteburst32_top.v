`timescale 1ns/1ps

module axi_liteburst32_top #(
    parameter ADDR_WIDTH     = 32,
    parameter DATA_WIDTH     = 32,
    parameter STRB_WIDTH     = DATA_WIDTH / 8,
    parameter BURST_LEN_BITS = 4,
    parameter MEM_BASE       = 32'h0000_0010,
    parameter MEM_SIZE       = 32'h0000_0400 // 1 KB internal RAM
)(
    input  wire                       s_axi_aclk,
    input  wire                       s_axi_aresetn,
    
    // Write Address Channel
    input  wire [ADDR_WIDTH-1:0]      s_axi_awaddr,
    input  wire [BURST_LEN_BITS-1:0]  s_axi_awlen,
    input  wire [1:0]                 s_axi_awburst,
    input  wire                       s_axi_awvalid,
    output wire                       s_axi_awready,
    
    // Write Data Channel
    input  wire [DATA_WIDTH-1:0]      s_axi_wdata,
    input  wire [STRB_WIDTH-1:0]      s_axi_wstrb,
    input  wire                       s_axi_wlast,
    input  wire                       s_axi_wvalid,
    output wire                       s_axi_wready,
    
    // Write Response Channel
    output wire [1:0]                 s_axi_bresp,
    output wire                       s_axi_bvalid,
    input  wire                       s_axi_bready,
    
    // Read Address Channel
    input  wire [ADDR_WIDTH-1:0]      s_axi_araddr,
    input  wire [BURST_LEN_BITS-1:0]  s_axi_arlen,
    input  wire [1:0]                 s_axi_arburst,
    input  wire                       s_axi_arvalid,
    output wire                       s_axi_arready,
    
    // Read Data Channel
    output wire [DATA_WIDTH-1:0]      s_axi_rdata,
    output wire [1:0]                 s_axi_rresp,
    output wire                       s_axi_rlast,
    output wire                       s_axi_rvalid,
    input  wire                       s_axi_rready,
    
    // Power & Debug Telemetry
    output wire                       core_idle_status
);

    // -------------------------------------------------------------------------
    // Internal Interconnect Nets
    // -------------------------------------------------------------------------
    wire gated_clk;
    wire fsm_busy, is_idle;
    assign core_idle_status = is_idle;

    // AW Channel outputs
    wire [ADDR_WIDTH-1:0]     aw_captured_addr;
    wire [BURST_LEN_BITS-1:0] aw_captured_len;
    wire [1:0]                aw_captured_burst;
    wire                      aw_handshake_done;
    wire                      aw_fifo_full;

    // W Channel outputs
    wire [DATA_WIDTH-1:0]     w_captured_data;
    wire [STRB_WIDTH-1:0]     w_captured_strb;
    wire                      w_captured_last;
    wire                      w_beat_ack;
    wire                      wlast_error;

    // B Channel outputs
    wire                      b_handshake_done;
    wire                      wr_complete_pulse;

    // AR Channel outputs
    wire [ADDR_WIDTH-1:0]     ar_captured_addr;
    wire [BURST_LEN_BITS-1:0] ar_captured_len;
    wire [1:0]                ar_captured_burst;
    wire                      ar_handshake_done;
    wire                      ar_pipe_busy;

    // R Channel outputs
    wire                      r_beat_ack;
    wire                      r_busy;

    // Burst Controller routing
    wire                      burst_start;
    wire                      beat_ack;
    wire [ADDR_WIDTH-1:0]     burst_init_addr;
    wire [BURST_LEN_BITS-1:0] burst_init_len;
    wire [1:0]                burst_init_type;
    wire [ADDR_WIDTH-1:0]     active_addr;
    wire [BURST_LEN_BITS-1:0] active_beat;
    wire                      is_last_beat;
    wire                      burst_busy;

    // FSM strobes
    wire                      burst_start_wr, burst_start_rd;
    wire                      wr_en, rd_en;

    assign burst_start     = burst_start_wr | burst_start_rd;
    assign beat_ack        = wr_en ? w_beat_ack : r_beat_ack;
    assign burst_init_addr = burst_start_wr ? aw_captured_addr  : ar_captured_addr;
    assign burst_init_len  = burst_start_wr ? aw_captured_len   : ar_captured_len;
    assign burst_init_type = burst_start_wr ? aw_captured_burst : ar_captured_burst;

    // Address Decoder & Response Nets
    wire sel_ctrl, sel_status, sel_config, sel_mem, dec_err;
    wire wr_prot_err;
    wire [1:0] gen_resp;

    // Datapath & Storage Nets
    wire [DATA_WIDTH-1:0] masked_wdata;
    wire                  ctrl_we, config_we;
    wire [STRB_WIDTH-1:0] mem_we;
    wire [DATA_WIDTH-1:0] reg_ctrl_data, reg_status_data, reg_config_data, mem_rdata;
    wire [DATA_WIDTH-1:0] staged_rdata;
    wire                  rdata_valid;

    // Hardware status bus driven to STATUS reg (0x04)
    wire [DATA_WIDTH-1:0] hw_status = {
        24'd0,
        wlast_error,        // Bit 7
        dec_err,            // Bit 6
        wr_prot_err,        // Bit 5
        is_idle,            // Bit 4
        burst_busy,         // Bit 3
        r_busy,             // Bit 2
        s_axi_bvalid,       // Bit 1
        fsm_busy            // Bit 0
    };

    // -------------------------------------------------------------------------
    // Sub-Module Instantiations
    // -------------------------------------------------------------------------

    // 1. Low-Power Controller
    low_power_controller #(
        .IDLE_TIMEOUT(16)
    ) u_low_power (
        .clk(s_axi_aclk),
        .aresetn(s_axi_aresetn),
        .awvalid(s_axi_awvalid),
        .wvalid(s_axi_wvalid),
        .arvalid(s_axi_arvalid),
        .b_busy(s_axi_bvalid),
        .r_busy(r_busy),
        .fsm_busy(fsm_busy),
        .gated_clk(gated_clk),
        .is_idle(is_idle)
    );

    // 2. Coordinating FSM
    axi_slave_fsm u_fsm (
        .clk(gated_clk),
        .aresetn(s_axi_aresetn),
        .aw_handshake_done(aw_handshake_done),
        .ar_handshake_done(ar_handshake_done),
        .w_beat_ack(w_beat_ack),
        .is_last_write_beat(is_last_beat),
        .r_beat_ack(r_beat_ack),
        .is_last_read_beat(is_last_beat),
        .b_handshake_done(b_handshake_done),
        .burst_start_wr(burst_start_wr),
        .burst_start_rd(burst_start_rd),
        .wr_en(wr_en),
        .rd_en(rd_en),
        .wr_complete_pulse(wr_complete_pulse),
        .fsm_busy(fsm_busy),
        .aw_fifo_full(aw_fifo_full),
        .ar_pipe_busy(ar_pipe_busy)
    );

    // 3. Burst Controller[cite: 6, 8]
    burst_controller #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(DATA_WIDTH),
        .BURST_LEN_BITS(BURST_LEN_BITS)
    ) u_burst_ctrl (
        .clk(gated_clk),
        .aresetn(s_axi_aresetn),
        .burst_start(burst_start),
        .beat_ack(beat_ack),
        .init_addr(burst_init_addr),
        .burst_len(burst_init_len),
        .burst_type(burst_init_type),
        .current_addr(active_addr),
        .current_beat(active_beat),
        .is_last_beat(is_last_beat),
        .burst_busy(burst_busy)
    );

    // 4. Address Decoder
    address_decoder #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .MEM_BASE(MEM_BASE),
        .MEM_SIZE(MEM_SIZE)
    ) u_addr_dec (
        .addr(active_addr),
        .addr_valid(fsm_busy),
        .sel_ctrl(sel_ctrl),
        .sel_status(sel_status),
        .sel_config(sel_config),
        .sel_mem(sel_mem),
        .dec_err(dec_err)
    );

    // 5. Response Generator[cite: 2, 8]
    response_generator u_resp_gen (
        .dec_err(dec_err),
        .wr_prot_err(wr_prot_err),
        .resp_out(gen_resp)
    );

    // 6. Write Address Channel[cite: 7, 8]
    axi_aw_channel #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .BURST_LEN_BITS(BURST_LEN_BITS)
    ) u_aw_chan (
        .clk(s_axi_aclk),
        .aresetn(s_axi_aresetn),
        .s_axi_awaddr(s_axi_awaddr),
        .s_axi_awlen(s_axi_awlen),
        .s_axi_awburst(s_axi_awburst),
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awready(s_axi_awready),
        .aw_fifo_full(aw_fifo_full),
        .aw_captured_addr(aw_captured_addr),
        .aw_captured_len(aw_captured_len),
        .aw_captured_burst(aw_captured_burst),
        .aw_handshake_done(aw_handshake_done)
    );

    // 7. Write Data Channel[cite: 5, 8]
    axi_w_channel #(
        .DATA_WIDTH(DATA_WIDTH),
        .STRB_WIDTH(STRB_WIDTH)
    ) u_w_chan (
        .clk(gated_clk),
        .aresetn(s_axi_aresetn),
        .s_axi_wdata(s_axi_wdata),
        .s_axi_wstrb(s_axi_wstrb),
        .s_axi_wlast(s_axi_wlast),
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wready(s_axi_wready),
        .w_fifo_full(!fsm_busy),
        .expected_last_beat(is_last_beat),
        .w_captured_data(w_captured_data),
        .w_captured_strb(w_captured_strb),
        .w_captured_last(w_captured_last),
        .w_beat_ack(w_beat_ack),
        .wlast_error(wlast_error)
    );

    // 8. Write Datapath[cite: 8]
    write_data_path #(
        .DATA_WIDTH(DATA_WIDTH),
        .STRB_WIDTH(STRB_WIDTH)
    ) u_wr_path (
        .clk(gated_clk),
        .aresetn(s_axi_aresetn),
        .wr_en(wr_en),
        .sel_ctrl(sel_ctrl),
        .sel_status(sel_status),
        .sel_config(sel_config),
        .sel_mem(sel_mem),
        .wdata(w_captured_data),
        .wstrb(w_captured_strb),
        .orig_data(mem_rdata),
        .masked_wdata(masked_wdata),
        .ctrl_we(ctrl_we),
        .config_we(config_we),
        .mem_we(mem_we),
        .wr_prot_err(wr_prot_err)
    );

    // 9. Write Response Channel[cite: 2, 8]
    axi_b_channel u_b_chan (
        .clk(s_axi_aclk),
        .aresetn(s_axi_aresetn),
        .wr_complete_pulse(wr_complete_pulse),
        .gen_bresp(gen_resp),
        .s_axi_bresp(s_axi_bresp),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_bready(s_axi_bready),
        .b_handshake_done(b_handshake_done)
    );

    // 10. Read Address Channel[cite: 7, 8]
    axi_ar_channel #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .BURST_LEN_BITS(BURST_LEN_BITS)
    ) u_ar_chan (
        .clk(s_axi_aclk),
        .aresetn(s_axi_aresetn),
        .s_axi_araddr(s_axi_araddr),
        .s_axi_arlen(s_axi_arlen),
        .s_axi_arburst(s_axi_arburst),
        .s_axi_arvalid(s_axi_arvalid),
        .s_axi_arready(s_axi_arready),
        .ar_pipe_busy(ar_pipe_busy),
        .ar_captured_addr(ar_captured_addr),
        .ar_captured_len(ar_captured_len),
        .ar_captured_burst(ar_captured_burst),
        .ar_handshake_done(ar_handshake_done)
    );

    // 11. Read Datapath[cite: 8]
    read_data_path #(
        .DATA_WIDTH(DATA_WIDTH)
    ) u_rd_path (
        .clk(gated_clk),
        .aresetn(s_axi_aresetn),
        .rd_en(rd_en),
        .sel_ctrl(sel_ctrl),
        .sel_status(sel_status),
        .sel_config(sel_config),
        .sel_mem(sel_mem),
        .dec_err(dec_err),
        .reg_ctrl_data(reg_ctrl_data),
        .reg_status_data(reg_status_data),
        .reg_config_data(reg_config_data),
        .mem_rdata(mem_rdata),
        .staged_rdata(staged_rdata),
        .rdata_valid(rdata_valid)
    );

    // 12. Read Data Channel[cite: 4, 8]
    axi_r_channel #(
        .DATA_WIDTH(DATA_WIDTH)
    ) u_r_chan (
        .clk(s_axi_aclk),
        .aresetn(s_axi_aresetn),
        .staged_rdata(staged_rdata),
        .staged_rvalid(rdata_valid),
        .gen_rresp(gen_resp),
        .is_last_beat(is_last_beat),
        .s_axi_rdata(s_axi_rdata),
        .s_axi_rresp(s_axi_rresp),
        .s_axi_rlast(s_axi_rlast),
        .s_axi_rvalid(s_axi_rvalid),
        .s_axi_rready(s_axi_rready),
        .r_beat_ack(r_beat_ack),
        .r_busy(r_busy)
    );

    // 13. Register and Memory Bank[cite: 8]
    reg_mem_bank #(
        .DATA_WIDTH(DATA_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .STRB_WIDTH(STRB_WIDTH),
        .MEM_DEPTH(256)
    ) u_mem_bank (
        .clk(gated_clk),
        .aresetn(s_axi_aresetn),
        .ctrl_we(ctrl_we),
        .config_we(config_we),
        .mem_we(mem_we),
        .wr_data(masked_wdata),
        .wr_addr(active_addr),
        .rd_addr(active_addr),
        .hw_status_in(hw_status),
        .reg_ctrl_out(reg_ctrl_data),
        .reg_status_out(reg_status_data),
        .reg_config_out(reg_config_data),
        .mem_rdata_out(mem_rdata)
    );

endmodule
`timescale 1ns/1ps

module response_generator (
    input  wire       dec_err,     // Unmapped address error from address_decoder
    input  wire       wr_prot_err, // Write protection violation (e.g., write to RO reg)
    output reg  [1:0] resp_out     // AXI response encoding (BRESP or RRESP)
);

    // Standard AXI Protocol Response Encodings
    localparam [1:0] RESP_OKAY   = 2'b00;
    localparam [1:0] RESP_EXOKAY = 2'b01; // Not used in AXI-Lite/single-slave without exclusive monitors
    localparam [1:0] RESP_SLVERR = 2'b10;
    localparam [1:0] RESP_DECERR = 2'b11;

    always @(*) begin
        if (dec_err) begin
            // Highest priority: address decoding failed
            resp_out = RESP_DECERR;
        end else if (wr_prot_err) begin
            // Second priority: slave protection error
            resp_out = RESP_SLVERR;
        end else begin
            // Normal successful access
            resp_out = RESP_OKAY;
        end
    end

endmodule
`timescale 1ns/1ps

module low_power_controller #(
    parameter IDLE_TIMEOUT = 16 // Number of idle cycles before sleep
)(
    input  wire clk,
    input  wire aresetn,
    
    // Activity indicators across AXI channels
    input  wire awvalid,
    input  wire wvalid,
    input  wire arvalid,
    input  wire b_busy,
    input  wire r_busy,
    input  wire fsm_busy,
    
    // Power management outputs
    output wire gated_clk,
    output wire is_idle
);

    reg [$clog2(IDLE_TIMEOUT):0] idle_cnt_r;
    reg                          clk_en_r;
    reg                          latch_en;

    // Detect any incoming bus transfer or in-flight burst processing
    wire bus_active;
    assign bus_active = awvalid || wvalid || arvalid || b_busy || r_busy || fsm_busy;

    // Idle timer logic
    always @(posedge clk) begin
        if (!aresetn) begin
            idle_cnt_r <= 0;
            clk_en_r   <= 1'b1; // Start fully awake
        end else begin
            if (bus_active) begin
                // Reset counter on any activity; keep clock alive
                idle_cnt_r <= 0;
                clk_en_r   <= 1'b1;
            end else if (idle_cnt_r < IDLE_TIMEOUT) begin
                idle_cnt_r <= idle_cnt_r + 1'b1;
                clk_en_r   <= 1'b1;
            end else begin
                // Timeout reached with zero bus activity: gate the clock
                clk_en_r   <= 1'b0;
            end
        end
    end

    // Wake-up override: any new incoming transaction immediately forces clock back on
    wire clk_enable_final;
    assign clk_enable_final = clk_en_r || bus_active;

    // -------------------------------------------------------------------------
    // Glitch-Free Integrated Clock Gating (ICG) Emulation Model
    // Uses a level-sensitive latch transparent on clk LOW (~clk)
    // -------------------------------------------------------------------------
    always @(clk or clk_enable_final or aresetn) begin
        if (!aresetn) begin
            latch_en <= 1'b1;
        end else if (!clk) begin
            latch_en <= clk_enable_final; // Samples enable ONLY while clock is LOW
        end
    end

    // Gated Clock output
    assign gated_clk = clk && latch_en;
    assign is_idle   = !clk_enable_final;

endmodule
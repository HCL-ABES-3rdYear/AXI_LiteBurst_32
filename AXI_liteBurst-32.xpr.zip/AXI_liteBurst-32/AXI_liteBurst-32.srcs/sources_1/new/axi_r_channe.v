`timescale 1ns/1ps

module axi_r_channel #(
    parameter DATA_WIDTH = 32
)(
    input  wire                   clk,
    input  wire                   aresetn,
    
    // Internal read pipeline inputs
    input  wire [DATA_WIDTH-1:0]  staged_rdata,
    input  wire                   staged_rvalid,
    input  wire [1:0]             gen_rresp,
    input  wire                   is_last_beat,
    
    // AXI4 Read Data Channel Interface
    output wire [DATA_WIDTH-1:0]  s_axi_rdata,
    output wire [1:0]             s_axi_rresp,
    output wire                   s_axi_rlast,
    output wire                   s_axi_rvalid,
    input  wire                   s_axi_rready,
    
    // Handshake feedback
    output wire                   r_beat_ack,
    output wire                   r_busy
);

    reg [DATA_WIDTH-1:0] rdata_r;
    reg [1:0]            rresp_r;
    reg                  rlast_r;
    reg                  rvalid_r;

    // Successful handshake completion
    assign r_beat_ack = rvalid_r && s_axi_rready;
    assign r_busy     = rvalid_r;

    always @(posedge clk) begin
        if (!aresetn) begin
            rdata_r  <= {DATA_WIDTH{1'b0}};
            rresp_r  <= 2'b00;
            rlast_r  <= 1'b0;
            rvalid_r <= 1'b0;
        end else begin
            if (staged_rvalid && (!rvalid_r || r_beat_ack)) begin
                // Accept new data when idle or simultaneously clearing previous handshake
                rdata_r  <= staged_rdata;
                rresp_r  <= gen_rresp;
                rlast_r  <= is_last_beat;
                rvalid_r <= 1'b1;
            end else if (r_beat_ack) begin
                // Handshake concluded without incoming data immediately following
                rvalid_r <= 1'b0;
                rlast_r  <= 1'b0;
            end
        end
    end

    assign s_axi_rdata  = rdata_r;
    assign s_axi_rresp  = rresp_r;
    assign s_axi_rlast  = rlast_r;
    assign s_axi_rvalid = rvalid_r;

endmodule
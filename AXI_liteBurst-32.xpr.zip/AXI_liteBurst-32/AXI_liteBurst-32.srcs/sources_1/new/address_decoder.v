`timescale 1ns/1ps

module address_decoder #(
    parameter ADDR_WIDTH = 32,
    parameter MEM_BASE   = 32'h0000_0010,
    parameter MEM_SIZE   = 32'h0000_0400  // 1 KB scratchpad RAM
)(
    input  wire [ADDR_WIDTH-1:0] addr,
    input  wire                  addr_valid,
    
    // Decoded select lines
    output reg                   sel_ctrl,
    output reg                   sel_status,
    output reg                   sel_config,
    output reg                   sel_mem,
    
    // Error flag
    output reg                   dec_err
);

    // Register offsets
    localparam [ADDR_WIDTH-1:0] ADDR_CTRL   = 32'h0000_0000;
    localparam [ADDR_WIDTH-1:0] ADDR_STATUS = 32'h0000_0004;
    localparam [ADDR_WIDTH-1:0] ADDR_CONFIG = 32'h0000_0008;
    localparam [ADDR_WIDTH-1:0] MEM_END    = MEM_BASE + MEM_SIZE - 1'b1;

    always @(*) begin
        // Default values to prevent inferred latches
        sel_ctrl   = 1'b0;
        sel_status = 1'b0;
        sel_config = 1'b0;
        sel_mem    = 1'b0;
        dec_err    = 1'b0;

        if (addr_valid) begin
            case (addr)
                ADDR_CTRL:   sel_ctrl   = 1'b1;
                ADDR_STATUS: sel_status = 1'b1;
                ADDR_CONFIG: sel_config = 1'b1;
                default: begin
                    // Check if address falls in Scratchpad Memory range
                    if ((addr >= MEM_BASE) && (addr <= MEM_END)) begin
                        sel_mem = 1'b1;
                    end else begin
                        // Address is in a hole or beyond memory bounds
                        dec_err = 1'b1;
                    end
                end
            endcase
        end
    end

endmodule
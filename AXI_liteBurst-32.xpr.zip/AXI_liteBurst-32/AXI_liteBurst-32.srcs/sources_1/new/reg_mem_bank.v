`timescale 1ns/1ps

module reg_mem_bank #(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 32,
    parameter STRB_WIDTH = DATA_WIDTH / 8,
    parameter MEM_DEPTH  = 256 // 256 words = 1024 bytes (1 KB)
)(
    input  wire                   clk,
    input  wire                   aresetn,
    
    // Register Write Enables
    input  wire                   ctrl_we,
    input  wire                   config_we,
    input  wire [STRB_WIDTH-1:0]  mem_we,
    
    // Write Bus
    input  wire [DATA_WIDTH-1:0]  wr_data,
    input  wire [ADDR_WIDTH-1:0]  wr_addr,
    
    // Read Bus
    input  wire [ADDR_WIDTH-1:0]  rd_addr,
    
    // External hardware status inputs (hardware drives STATUS register)
    input  wire [DATA_WIDTH-1:0]  hw_status_in,
    
    // Internal Register & Memory Read Outputs
    output reg  [DATA_WIDTH-1:0]  reg_ctrl_out,
    output wire [DATA_WIDTH-1:0]  reg_status_out,
    output reg  [DATA_WIDTH-1:0]  reg_config_out,
    output reg  [DATA_WIDTH-1:0]  mem_rdata_out
);

    // Register File Storage
    reg [DATA_WIDTH-1:0] ctrl_reg_r;
    reg [DATA_WIDTH-1:0] config_reg_r;

    // 1 KB Scratchpad Memory (256 x 32-bit array)
    reg [DATA_WIDTH-1:0] ram_matrix [0:MEM_DEPTH-1];

    // Word indexing calculation: Drop lower 2 byte-offset bits and base offset 0x10
    wire [$clog2(MEM_DEPTH)-1:0] wr_mem_index;
    wire [$clog2(MEM_DEPTH)-1:0] rd_mem_index;

    assign wr_mem_index = wr_addr[9:2] - 8'h04; // 0x10 >> 2 = index 0
    assign rd_mem_index = rd_addr[9:2] - 8'h04;

    // Sequential Write Operations
    integer b;
    always @(posedge clk) begin
        if (!aresetn) begin
            ctrl_reg_r   <= {DATA_WIDTH{1'b0}};
            config_reg_r <= {DATA_WIDTH{1'b0}};
        end else begin
            if (ctrl_we) begin
                ctrl_reg_r <= wr_data;
            end
            if (config_we) begin
                config_reg_r <= wr_data;
            end
        end
    end

    // Memory Array Byte-Enable Writes (Infers Block RAM in Vivado)
    always @(posedge clk) begin
        for (b = 0; b < STRB_WIDTH; b = b + 1) begin
            if (mem_we[b]) begin
                ram_matrix[wr_mem_index][(b*8) +: 8] <= wr_data[(b*8) +: 8];
            end
        end
    end

    // Synchronous Memory Read (BRAM output register)
    always @(posedge clk) begin
        if (!aresetn) begin
            mem_rdata_out <= {DATA_WIDTH{1'b0}};
        end else begin
            mem_rdata_out <= ram_matrix[rd_mem_index];
        end
    end

    // Continuous Register Read Outputs
    assign reg_status_out = hw_status_in; // Strictly driven by internal hardware logic
    always @(*) begin
        reg_ctrl_out   = ctrl_reg_r;
        reg_config_out = config_reg_r;
    end

endmodule
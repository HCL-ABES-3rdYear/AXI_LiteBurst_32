`timescale 1ns/1ps

module read_data_path #(
    parameter DATA_WIDTH = 32
)(
    input  wire                   clk,
    input  wire                   aresetn,
    
    // Control & address selection lines
    input  wire                   rd_en,
    input  wire                   sel_ctrl,
    input  wire                   sel_status,
    input  wire                   sel_config,
    input  wire                   sel_mem,
    input  wire                   dec_err,
    
    // Data inputs from internal storage blocks
    input  wire [DATA_WIDTH-1:0]  reg_ctrl_data,
    input  wire [DATA_WIDTH-1:0]  reg_status_data,
    input  wire [DATA_WIDTH-1:0]  reg_config_data,
    input  wire [DATA_WIDTH-1:0]  mem_rdata,
    
    // Output toward axi_r_channel
    output reg  [DATA_WIDTH-1:0]  staged_rdata,
    output reg                    rdata_valid
);

    reg [DATA_WIDTH-1:0] muxed_data;

    // Combinational multiplexing of data sources
    always @(*) begin
        if (dec_err) begin
            muxed_data = {DATA_WIDTH{1'b0}}; // Safe zero vector on unmapped addresses
        end else if (sel_ctrl) begin
            muxed_data = reg_ctrl_data;
        end else if (sel_status) begin
            muxed_data = reg_status_data;
        end else if (sel_config) begin
            muxed_data = reg_config_data;
        end else if (sel_mem) begin
            muxed_data = mem_rdata;
        end else begin
            muxed_data = {DATA_WIDTH{1'b0}};
        end
    end

    // Sequential staging register
    always @(posedge clk) begin
        if (!aresetn) begin
            staged_rdata <= {DATA_WIDTH{1'b0}};
            rdata_valid  <= 1'b0;
        end else begin
            if (rd_en) begin
                staged_rdata <= muxed_data;
                rdata_valid  <= 1'b1;
            end else begin
                rdata_valid  <= 1'b0;
            end
        end
    end

endmodule
`timescale 1ns/1ps

module axi_slave_fsm (
    input  wire clk,
    input  wire aresetn,
    
    // Address channel handshakes
    input  wire aw_handshake_done,
    input  wire ar_handshake_done,
    
    // Burst progress indicators
    input  wire w_beat_ack,
    input  wire is_last_write_beat,
    input  wire r_beat_ack,
    input  wire is_last_read_beat,
    input  wire b_handshake_done,
    
    // Pipeline control strobes
    output reg  burst_start_wr,
    output reg  burst_start_rd,
    output reg  wr_en,
    output reg  rd_en,
    output reg  wr_complete_pulse,
    output reg  fsm_busy,
    output reg  aw_fifo_full,
    output reg  ar_pipe_busy
);

    localparam [2:0] S_IDLE     = 3'b000;
    localparam [2:0] S_WR_BURST = 3'b001;
    localparam [2:0] S_WR_RESP  = 3'b010;
    localparam [2:0] S_RD_PIPE  = 3'b011;
    localparam [2:0] S_RD_BURST = 3'b100;

    reg [2:0] state_r, next_state;

    // State Register
    always @(posedge clk) begin
        if (!aresetn) begin
            state_r <= S_IDLE;
        end else begin
            state_r <= next_state;
        end
    end

    // Next-State Combinational Logic
    always @(*) begin
        next_state = state_r;
        case (state_r)
            S_IDLE: begin
                if (aw_handshake_done) begin
                    next_state = S_WR_BURST;
                end else if (ar_handshake_done) begin
                    next_state = S_RD_PIPE;
                end
            end
            
            S_WR_BURST: begin
                if (w_beat_ack && is_last_write_beat) begin
                    next_state = S_WR_RESP;
                end
            end
            
            S_WR_RESP: begin
                if (b_handshake_done) begin
                    next_state = S_IDLE;
                end
            end
            
            S_RD_PIPE: begin
                // 1-cycle memory staging latency
                next_state = S_RD_BURST;
            end
            
            S_RD_BURST: begin
                if (r_beat_ack && is_last_read_beat) begin
                    next_state = S_IDLE;
                end else if (r_beat_ack) begin
                    // Pipeline staging for subsequent beats
                    next_state = S_RD_PIPE;
                end
            end
            
            default: next_state = S_IDLE;
        endcase
    end

    // Control Outputs
    always @(*) begin
        burst_start_wr    = 1'b0;
        burst_start_rd    = 1'b0;
        wr_en             = 1'b0;
        rd_en             = 1'b0;
        wr_complete_pulse = 1'b0;
        fsm_busy          = 1'b0;
        aw_fifo_full      = 1'b0;
        ar_pipe_busy      = 1'b0;

        case (state_r)
            S_IDLE: begin
                if (aw_handshake_done) begin
                    burst_start_wr = 1'b1;
                    aw_fifo_full   = 1'b1;
                end else if (ar_handshake_done) begin
                    burst_start_rd = 1'b1;
                    ar_pipe_busy   = 1'b1;
                end
            end
            
            S_WR_BURST: begin
                fsm_busy     = 1'b1;
                aw_fifo_full = 1'b1;
                ar_pipe_busy = 1'b1; // Block reads during active write burst
                wr_en        = w_beat_ack;
                if (w_beat_ack && is_last_write_beat) begin
                    wr_complete_pulse = 1'b1;
                end
            end
            
            S_WR_RESP: begin
                fsm_busy     = 1'b1;
                aw_fifo_full = 1'b1;
                ar_pipe_busy = 1'b1;
            end
            
            S_RD_PIPE: begin
                fsm_busy     = 1'b1;
                aw_fifo_full = 1'b1;
                ar_pipe_busy = 1'b1;
                rd_en        = 1'b1; // Trigger memory/register read fetch
            end
            
            S_RD_BURST: begin
                fsm_busy     = 1'b1;
                aw_fifo_full = 1'b1;
                ar_pipe_busy = 1'b1;
            end
        endcase
    end

endmodule